"use client";

import { useMemo, useState } from "react";
import { AlertCircle, CheckCircle2 } from "lucide-react";

/**
 * ROI-калькулятор найма. Формулы 1:1 из старого pages/calculator.html:
 *   hourR        = fot_recruiter / 170
 *   hourM        = fot_manager / 170
 *   dayVacancy   = salary / 21
 *   relCand      = responses * 0.6
 *
 *   --- Без BRaiN HR (25 дней) ---
 *   oldRecruiter = (responses*5/60 + relCand*10/60 + 60*60/60) * hourR
 *   oldManager   = (24*10/60 + 12*60/60) * hourM
 *   oldDowntime  = dayVacancy * 25
 *   oldTotal     = oldRecruiter + oldManager + oldDowntime
 *
 *   --- С BRaiN HR (7 дней + 27 000 руб./мес стоимости платформы) ---
 *   newRecruiter = (20*10/60) * hourR
 *   newManager   = (20*10/60 + 5*60/60) * hourM
 *   newDowntime  = dayVacancy * 7
 *   newTotal     = newRecruiter + newManager + newDowntime + 27000
 *
 *   savings        = oldTotal - newTotal
 *   annualSavings  = savings * vacancies_year
 */

const BRAIN_COST = 27000;
const OLD_DAYS = 25;
const NEW_DAYS = 7;

const DEFAULTS = {
  fot_recruiter: 80000,
  fot_manager: 150000,
  salary: 100000,
  responses: 500,
  vacancies_year: 24,
} as const;

type Inputs = typeof DEFAULTS;

function calculate(i: Inputs) {
  const hourR = i.fot_recruiter / 170;
  const hourM = i.fot_manager / 170;
  const dayVacancy = i.salary / 21;
  const relCand = i.responses * 0.6;

  const oldRecruiter = (i.responses * 5) / 60 * hourR + (relCand * 10) / 60 * hourR + (60 * 60) / 60 * hourR;
  const oldManager = (24 * 10) / 60 * hourM + (12 * 60) / 60 * hourM;
  const oldDowntime = dayVacancy * OLD_DAYS;
  const oldTotal = oldRecruiter + oldManager + oldDowntime;

  const newRecruiter = (20 * 10) / 60 * hourR;
  const newManager = (20 * 10) / 60 * hourM + (5 * 60) / 60 * hourM;
  const newDowntime = dayVacancy * NEW_DAYS;
  const newTotal = newRecruiter + newManager + newDowntime + BRAIN_COST;

  const savings = oldTotal - newTotal;
  const annualSavings = savings * i.vacancies_year;

  return {
    oldRecruiter, oldManager, oldDowntime, oldTotal,
    newRecruiter, newManager, newDowntime, newTotal,
    savings, annualSavings,
  };
}

const fmt = (n: number) =>
  Math.round(n).toLocaleString("ru-RU").replace(/,/g, " ") + " руб.";

export function RoiCalculator() {
  const [inputs, setInputs] = useState<Inputs>(DEFAULTS);

  const result = useMemo(() => calculate(inputs), [inputs]);

  const onChange = (key: keyof Inputs) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = Number.parseInt(e.target.value.replace(/\D/g, ""), 10);
    setInputs((prev) => ({ ...prev, [key]: Number.isFinite(raw) ? raw : 0 }));
  };

  const reset = () => setInputs(DEFAULTS);

  return (
    <div id="calculator" className="overflow-hidden rounded-card border border-grey2 bg-white shadow-md">
      <div className="border-b border-grey2 bg-grey1 px-6 py-4">
        <div className="text-[14px] font-bold text-text1">
          Калькулятор стоимости закрытия вакансии
        </div>
        <div className="mt-0.5 text-[12px] text-text2">
          Введите параметры — расчёт обновится автоматически
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 p-7 max-bp-lg:grid-cols-1 max-bp-lg:gap-6 max-bp-sm:p-5">
        {/* INPUTS */}
        <div className="flex flex-col gap-4">
          <CalcInput
            label="ФОТ рекрутера"
            suffix="руб./мес"
            value={inputs.fot_recruiter}
            onChange={onChange("fot_recruiter")}
          />
          <CalcInput
            label="ФОТ руководителя"
            suffix="руб./мес"
            value={inputs.fot_manager}
            onChange={onChange("fot_manager")}
          />
          <CalcInput
            label="Зарплата специалиста"
            suffix="руб./мес"
            value={inputs.salary}
            onChange={onChange("salary")}
          />
          <CalcInput
            label="Откликов на вакансию"
            suffix="шт."
            value={inputs.responses}
            onChange={onChange("responses")}
          />
          <CalcInput
            label="Вакансий в год"
            suffix="шт."
            value={inputs.vacancies_year}
            onChange={onChange("vacancies_year")}
          />

          <button
            type="button"
            onClick={reset}
            className="mt-1 inline-flex items-center justify-center gap-1.5 self-start rounded-[8px] border border-grey2 bg-white px-4 py-2 text-[12px] font-semibold text-text2 transition-colors hover:border-brand1 hover:text-brand1"
          >
            Сбросить значения
          </button>
        </div>

        {/* COMPARISON TABLE */}
        <div className="grid grid-cols-2 overflow-hidden rounded-card border border-grey2 max-bp-sm:grid-cols-1">
          {/* Без BRaiN HR */}
          <div className="border-r border-grey2 bg-white max-bp-sm:border-b max-bp-sm:border-r-0">
            <div className="flex items-center gap-2 border-b border-grey2 bg-grey1 px-4 py-3 text-[12px] font-bold text-text2">
              <AlertCircle size={14} strokeWidth={2} />
              Без BRaiN HR
            </div>
            <div className="flex flex-col">
              <CalcRow label="Время закрытия" value={`${OLD_DAYS} дней`} />
              <CalcRow label="Стоимость рекрутера" value={fmt(result.oldRecruiter)} />
              <CalcRow label="Стоимость руководителя" value={fmt(result.oldManager)} />
              <CalcRow label="Цена простоя" value={fmt(result.oldDowntime)} />
              <CalcRow label="Стоимость BRaiN HR" value="—" muted />
              <div className="border-t border-grey2 bg-[#FEE2E2]/50 px-4 py-3 text-center">
                <div className="text-[11px] font-semibold uppercase tracking-[0.5px] text-[#B42318]">
                  Итого на 1 вакансию
                </div>
                <div className="mt-0.5 text-[18px] font-extrabold text-[#B42318]">
                  {fmt(result.oldTotal)}
                </div>
              </div>
            </div>
          </div>

          {/* С BRaiN HR */}
          <div className="bg-white">
            <div className="flex items-center gap-2 border-b border-brand1/30 bg-brand1-bg px-4 py-3 text-[12px] font-bold text-brand1">
              <CheckCircle2 size={14} strokeWidth={2} />
              С BRaiN HR
            </div>
            <div className="flex flex-col">
              <CalcRow label="Время закрытия" value={`${NEW_DAYS} дней`} highlight />
              <CalcRow label="Стоимость рекрутера" value={fmt(result.newRecruiter)} />
              <CalcRow label="Стоимость руководителя" value={fmt(result.newManager)} />
              <CalcRow label="Цена простоя" value={fmt(result.newDowntime)} />
              <CalcRow label="Стоимость BRaiN HR" value={fmt(BRAIN_COST)} />
              <div className="border-t border-brand1/30 bg-brand1-bg px-4 py-3 text-center">
                <div className="text-[11px] font-semibold uppercase tracking-[0.5px] text-brand1">
                  Итого на 1 вакансию
                </div>
                <div className="mt-0.5 text-[18px] font-extrabold text-brand1">
                  {fmt(result.newTotal)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SAVINGS BAR */}
      <div className="grid grid-cols-2 gap-4 border-t border-grey2 bg-gradient-to-r from-brand1-bg to-brand2-bg px-7 py-6 max-bp-sm:grid-cols-1 max-bp-sm:px-5">
        <div>
          <div className="text-[12px] font-semibold uppercase tracking-[0.5px] text-text2">
            Выгода на каждой вакансии
          </div>
          <div className="mt-1 text-[clamp(24px,3vw,36px)] font-extrabold leading-[1.1] text-brand1">
            {fmt(result.savings)}
          </div>
        </div>
        <div>
          <div className="text-[12px] font-semibold uppercase tracking-[0.5px] text-text2">
            Экономия за год
          </div>
          <div className="mt-1 text-[clamp(24px,3vw,36px)] font-extrabold leading-[1.1] text-brand2">
            {fmt(result.annualSavings)}
          </div>
        </div>
      </div>

      <div className="border-t border-grey2 bg-grey1 px-7 py-4 text-[11px] leading-[1.55] text-text2 max-bp-sm:px-5">
        В таблице приведены ориентировочные данные для расчёта затрат на поиск по одной вакансии. Стоимость открытой вакансии основана на HR-исследованиях.
      </div>
    </div>
  );
}

type CalcInputProps = {
  label: string;
  suffix: string;
  value: number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
};

function CalcInput({ label, suffix, value, onChange }: CalcInputProps) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[12px] font-semibold text-text1">{label}</span>
      <div className="flex items-center gap-2 rounded-[8px] border border-grey2 bg-white px-3.5 py-2.5 transition-colors focus-within:border-brand1 focus-within:ring-2 focus-within:ring-brand1/20">
        <input
          type="text"
          inputMode="numeric"
          value={value.toLocaleString("ru-RU").replace(/,/g, " ")}
          onChange={onChange}
          className="flex-1 bg-transparent text-[14px] font-semibold text-text1 outline-none"
        />
        <span className="shrink-0 text-[11px] font-medium text-text2">{suffix}</span>
      </div>
    </label>
  );
}

function CalcRow({
  label,
  value,
  highlight,
  muted,
}: {
  label: string;
  value: string;
  highlight?: boolean;
  muted?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-grey2 px-4 py-2.5 last:border-b-0">
      <span className="text-[12px] text-text2">{label}</span>
      <span
        className={[
          "text-[13px] font-semibold",
          muted ? "text-text2/60" : "text-text1",
          highlight ? "text-brand1" : "",
        ]
          .filter(Boolean)
          .join(" ")}
      >
        {value}
      </span>
    </div>
  );
}
